
/*
	$("h1").css("color","red");
	$("p").first().css("color","aqua");


$("h1").text("Hello Raj"); like textContent text() is used

*/ 
/*$("button").html("<em>mine</em>");//like innerhtml

*/
/*
$("img").addClass("images");//adding classes using jquery 
$("button").click(function(){
	$("h1").css("color","red");
});
*/
//showing the key pressed 

$(document).keypress(function(event){
	$("h1").text(event.key);
});


$("button").first().on("click",function(){
	alert("hey the on method is the best way to addeventlistener");
});